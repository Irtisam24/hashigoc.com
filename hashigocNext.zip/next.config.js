module.exports = {
  basePath: "",
  trailingSlash: true,
};
